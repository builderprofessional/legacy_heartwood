<?php
ob_start();
include 'contentheader.php';

    if( $frontback != "back" )
    {
        header("Location: index.php");
        exit();
    }

    $data = Array();
    $id = -1;
    $vid = -1;

    if( isset($_REQUEST['id']) )
    {
        $id = mysql_real_escape_string($_REQUEST['id'], $conn);
        $result = mysql_query("SELECT * FROM `videos` WHERE `id` = '$id'", $conn);
        $data = mysql_fetch_array($result);
        $vid = $data['videoID'];
    }

?>
    <link rel="stylesheet" href="modules/bseVideo/includes/modBseVideos.css" type="text/css" media="screen" />
    <div style="margin-left:auto; margin-right:auto; width:400px; margin-bottom:45px; margin-top:25px; ">
        <form method="post" action="addVideo.php">
        <h2 style="font-family:Arial, Verdana, Sans, Times; font-size:15px;">Enter the Title and Description of the Video.</h2>
            <div style="width:280px;">
                <div class="option">Video Title</div>
                <input type="text" name="title" style="width:100%; margin-bottom:15px;" value="<?=$data['title']?>" />
                <div class="option">Video Description</div>
                <input type="text" name="desc" style="width:100%; margin-bottom:15px;" value="<?=$data['description']?>" />
                <?php if( $id != -1 ) {echo "<input type='hidden' name='videoID' value='$id' />\n";} ?>
                <div style="width:100%; text-align:right; "><?php if( $id != -1 ){ echo "<input type=\"button\" value=\"Delete\" onmouseup=\"document.location.href='delVideo.php?id=$id&vid=$vid';\" /> ";} ?><input type="button" value="Cancel" onmouseup="document.location.href='index.php';" /> <input type="submit" value="Save" /></div>
            </div>
        </form>
    </div>
<?php 
    include("contentfooter.php"); 
    ob_flush();
?>