<?php
include 'setupadmin.php';

    if( $_SESSION['admin_logged_in'] != 1 )
    {
        header("Location: videos.php");
        exit();
    }

    $title = mysql_real_escape_string($_POST['title'], $conn);
    $desc = mysql_real_escape_string($_POST['desc'], $conn);
    
    $query = "INSERT INTO `videos` ";
    $where = "";
    if( isset($_POST['videoID']) )
    {
        $query = "UPDATE `videos` ";
        $where = "WHERE `id` = '".mysql_real_escape_string($_POST['videoID'], $conn)."'";
    }
    $query .= "SET `title`='$title', `description`='$desc' $where";
    $result = mysql_query($query, $conn) or die(mysql_error());
    $_SESSION['vidInsertID'] = mysql_insert_id();
    
    if( !isset($_POST['videoID']) )
        header("Location: modules/bseVideo/upload/upload.php?page=saveVidID.php");
        
    else
        header("Location: videos.php");
?>
