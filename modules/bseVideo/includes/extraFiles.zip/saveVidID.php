<?php
include 'setupadmin.php';

    if( $_SESSION['admin_logged_in'] != 1 )
    {
        header("Location: videos.php");
        exit();
    }
    
    if( $_GET['cancel'] == "cancel" )
    {
        $id = mysql_real_escape_string($_SESSION['vidInsertID'], $conn);
        mysql_query("DELETE FROM `videos` WHERE `id` = '$id' LIMIT 1", $conn);
        header("Location: index.php");
        exit();
    }
    
    $id = mysql_real_escape_string($_SESSION['newVidID'], $conn);
    $res = mysql_query("SELECT `title` FROM `videos` WHERE `id` = '{$_SESSION['vidInsertID']}'", $conn); 
    $data = mysql_fetch_array($res);
    $title = $data['title'];
    $query = "UPDATE `videos` SET `videoID`='$id' WHERE `id` = '{$_SESSION['vidInsertID']}'";
    $result = mysql_query($query, $conn) or die(mysql_error($conn));
    mysql_query("UPDATE `bseVideos` SET `title` = '$title' WHERE `id` = '$id'", $conn);
    
    header("Location: videos.php");

?>
