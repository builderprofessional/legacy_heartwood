<?php
include 'setupadmin.php';

    if( $_SESSION['admin_logged_in'] != 1 )
    {
        header("Location: videos.php");
        exit();
    }
    
    if( isset($_GET['id']) )
    {
        if( empty($_GET['id']) )
        {
            header("Location: videos.php");
            exit();
        }

        $id = mysql_real_escape_string($_GET['id']);
        $vid = $_GET['vid'];
        $query = "DELETE FROM `videos` WHERE `id` = '$id' LIMIT 1";
        mysql_query($query);
    }
    header("Location: modules/bseVideo/delete.php?vid=$vid&page=videos.php");
?>
